﻿using libplctag;
using libplctag.DataTypes;
using Microsoft.Azure.Devices.Client;
using Microsoft.Azure.Devices.Client.Transport.Mqtt;
using Microsoft.Azure.Devices.Shared;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Text;

namespace PLCModule;

internal class ModuleBackgroundService : BackgroundService
{
    private int _counter;
    private ModuleClient? _moduleClient;
    private CancellationToken _cancellationToken;
    private readonly ILogger<ModuleBackgroundService> _logger;

    public ModuleBackgroundService(ILogger<ModuleBackgroundService> logger) => _logger = logger;

    protected override async Task ExecuteAsync(CancellationToken cancellationToken)
    {
        _cancellationToken = cancellationToken;
        MqttTransportSettings mqttSetting = new(TransportType.Mqtt_Tcp_Only);
        ITransportSettings[] settings = { mqttSetting };

        // Open a connection to the Edge runtime
        _moduleClient = await ModuleClient.CreateFromEnvironmentAsync(settings);

        // Reconnect is not implented because we'll let docker restart the process when the connection is lost
        _moduleClient.SetConnectionStatusChangesHandler((status, reason) =>
            _logger.LogWarning("Connection changed: Status: {status} Reason: {reason}", status, reason));

        await _moduleClient.OpenAsync(cancellationToken);

        _logger.LogInformation("IoT Hub module client initialized.");

        var twin = await this._moduleClient.GetTwinAsync();
        RegisterTags(twin.Properties.Desired);
    }

    private void RegisterTags(TwinCollection desiredProperties)
    {
        this._logger.LogInformation("Registering tags");

        foreach (var item in desiredProperties["tags"])
        {
            var tagDefinition = JsonConvert.DeserializeObject<TagDefinition>(item.ToString());

            ThreadPool.QueueUserWorkItem(async (state) => await StartTagPolling(tagDefinition));
        }
    }

    private async Task StartTagPolling(TagDefinition tag)
    {
        this._logger.LogDebug($"Tag: {tag.TagName}, PollingInterval: {tag.PollingInterval}");

        using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(tag.PollingInterval));
        this._logger.LogTrace($"Starting polling for tag {tag.TagName}");

        do
        {
            try
            {
                await timer.WaitForNextTickAsync();

                await this.ReadAndSendTagValueAsync(tag);
            }
            catch (Exception e)
                when (e is TaskCanceledException || e is OperationCanceledException)
            {
                _logger.LogInformation("Polling for tag {0} cancelled", tag.TagName);
                return;
            }
            catch (Exception e)
                when (e is LibPlcTagException)
            {
                this._logger.LogError(e, "Error while polling tag");
                return;
            }
        }
        while (true);
    }

    private async Task ReadAndSendTagValueAsync(TagDefinition tag)
    {
        using var plcTag = new Tag<DintPlcMapper, int>();

        plcTag.Name = tag.TagName;
        plcTag.Gateway = tag.Gateway;
        plcTag.Path = tag.Path;
        plcTag.PlcType = tag.PlcType;
        plcTag.Protocol = Protocol.ab_eip;
        plcTag.ReadCacheMillisecondDuration = 0;

        this._logger.LogTrace("Polling tag {0}", tag.TagName);
        plcTag.Read();

        if (plcTag.GetStatus() != Status.Ok)
        {
            this._logger.LogWarning($"Tag {tag.TagName} is not OK - {plcTag.GetStatus()}");
            return;
        }

        var jsonTagValue = JsonConvert.SerializeObject(plcTag.Value);
        var jsonEvent = JObject.Parse($"{{\"{tag.Name}\":{jsonTagValue}}}");
        var jsonData = jsonEvent.ToString();

        this._logger.LogTrace("Sending message for tag {0} with value: {1}", tag.TagName, jsonData);

        var message = new Message(Encoding.UTF8.GetBytes(jsonData));

        await this._moduleClient.SendEventAsync("tag", message);

        this._logger.LogTrace("Message queued for tag {0}", tag.TagName);
    }
}
