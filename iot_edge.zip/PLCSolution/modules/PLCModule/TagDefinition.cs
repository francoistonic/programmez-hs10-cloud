namespace PLCModule;

using libplctag;

public class TagDefinition
{
    public string Name { get;set; }
    
    public string Gateway { get; set; }

    public string Path { get; set; }

    public string TagName { get; set; }

    public int PollingInterval { get; set; }

    public PlcType PlcType { get; set; } = PlcType.ControlLogix;
}
